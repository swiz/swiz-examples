This is the source for the simple example application used in the Quick Start section of the Swiz documentation wiki:

http://swizframework.jira.com/wiki/display/SWIZ/Quick+Start


